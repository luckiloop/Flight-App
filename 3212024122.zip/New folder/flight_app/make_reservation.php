<?php
session_start();
require_once 'includes/db.php';

// Ασφάλεια
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'customer') {
    die("Μη εξουσιοδοτημένη πρόσβαση.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $flight_number = $_POST['flight_number'];
    $ticket_type = $_POST['ticket_type']; 

    //Έλεγχος αν η πτήση είναι ακόμα διαθέσιμη για κρατήσεις
    $flight_stmt = $pdo->prepare("SELECT status FROM flights WHERE flight_number = ?");
    $flight_stmt->execute([$flight_number]);
    $flight = $flight_stmt->fetch();

    if (!$flight || $flight['status'] !== 'ΔΗΜΙΟΥΡΓΗΜΕΝΗ') {
        die("<span style='color:red;'>Σφάλμα: Δεν επιτρέπονται κρατήσεις σε αυτή την πτήση πλέον.</span>");
    }

    //Εισαγωγή της Κράτησης στη βάση με Prepared Statement
    // Τα πεδία id, reservation_date και modification_date μπαίνουν αυτόματα από τη βάση
    // Οι θέσεις (seat_row, seat_column) μένουν NULL αρχικά, όπως ζητάει η εκφώνηση
    $sql = "INSERT INTO reservations (user_id, flight_number, type, status, seat_row, seat_column) 
            VALUES (?, ?, ?, 'ΔΗΜΙΟΥΡΓΗΜΕΝΗ', NULL, NULL)";
    
    $stmt = $pdo->prepare($sql);
    
    try {
        $stmt->execute([$user_id, $flight_number, $ticket_type]);
        header("Location: search_flights.php?booking=success");
        exit();
        
    } catch (PDOException $e) {
        die("Σφάλμα κατά την κράτηση: " . $e->getMessage());
    }
} else {
    header("Location: search_flights.php");
    exit;
}
?>