<?php
session_start();
require_once 'includes/db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'customer') {
    die("Μη εξουσιοδοτημένη πρόσβαση.");
}

$user_id = $_SESSION['user_id'];
$res_id = (int)$_GET['res_id'];
$row = (int)$_GET['row'];
$col = (int)$_GET['col'];

//Έλεγχος αν η κράτηση ανήκει όντως στον συνδεδεμένο χρήστη και ποια είναι η πτήση
$stmt = $pdo->prepare("SELECT flight_number, type FROM reservations WHERE id = ? AND user_id = ?");
$stmt->execute([$res_id, $user_id]);
$res = $stmt->fetch();

if (!$res) {
    die("Η κράτηση δεν βρέθηκε.");
}

$flight_number = $res['flight_number'];

//Έλεγχος αν η θέση καταλήφθηκε από άλλον στο μεταξύ
$check_stmt = $pdo->prepare("SELECT id FROM reservations WHERE flight_number = ? AND seat_row = ? AND seat_column = ? AND status != 'ΑΚΥΡΩΜΕΝΗ'");
$check_stmt->execute([$flight_number, $row, $col]);

if ($check_stmt->rowCount() > 0) {
    die("<script>alert('Σφάλμα: Αυτή η θέση έχει ήδη καταληφθεί από άλλον επιβάτη!'); window.location.href='my_reservations.php';</script>");
}

//Ενημέρωση της θέσης στην κράτηση (Αλλαγή / Δέσμευση θέσης)
$update_stmt = $pdo->prepare("UPDATE reservations SET seat_row = ?, seat_column = ? WHERE id = ?");

try {
    $update_stmt->execute([$row, $col, $res_id]);
    header("Location: my_reservations.php");
    exit;
} catch (PDOException $e) {
    die("Σφάλμα κατά την επιλογή θέσης: " . $e->getMessage());
}
?>