<?php
session_start();
require_once 'includes/db.php';

//Ασφάλεια
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'system_admin') {
    die("Μη εξουσιοδοτημένη πρόσβαση.");
}

if (isset($_GET['id'])) {
    $user_id = (int)$_GET['id'];

    //Μάθε την τρέχουσα κατάσταση του χρήστη
    $stmt = $pdo->prepare("SELECT status FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if ($user) {
        //Αν είναι active γίνεται inactive, αν είναι inactive γίνεται active
        $new_status = ($user['status'] === 'active') ? 'inactive' : 'active';

        //Ενημέρωση στη βάση
        $update_stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
        $update_stmt->execute([$new_status, $user_id]);
    }
}

//Επιστροφή στη σελίδα διαχείρισης χρηστών
header("Location: manage_users.php");
exit;
?>