<?php
session_start();
require_once 'includes/db.php';

//Ασφάλεια
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'flight_admin' && $_SESSION['role'] !== 'system_admin')) {
    die("Μη εξουσιοδοτημένη πρόσβαση.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $flight_number = trim($_POST['flight_number']);
    $airplane = trim($_POST['airplane']);
    $flight_date = $_POST['flight_date'];
    $flight_time = $_POST['flight_time'];
    $rows_count = (int)$_POST['rows_count'];
    $seats_per_row = (int)$_POST['seats_per_row'];
    $business_rows = (int)$_POST['business_rows'];

    //Αυτόματος υπολογισμός συνολικών θέσεων (Rows * Seats per Row)
    $total_seats = $rows_count * $seats_per_row;

    //Έλεγχος αν ο αριθμός πτήσης υπάρχει ήδη (Μοναδικότητα)
    $check_stmt = $pdo->prepare("SELECT flight_number FROM flights WHERE flight_number = ?");
    $check_stmt->execute([$flight_number]);
    
    if ($check_stmt->rowCount() > 0) {
        die("<span style='color:red;'>Σφάλμα: Ο αριθμός πτήσης " . htmlspecialchars($flight_number) . " υπάρχει ήδη!</span>");
    }

    //Εισαγωγή στη βάση
    $sql = "INSERT INTO flights (flight_number, airplane, flight_date, flight_time, total_seats, rows_count, seats_per_row, business_rows, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'ΔΗΜΙΟΥΡΓΗΜΕΝΗ')";
    
    $stmt = $pdo->prepare($sql);
    
    try {
        $stmt->execute([
            $flight_number,
            $airplane,
            $flight_date,
            $flight_time,
            $total_seats,
            $rows_count,
            $seats_per_row,
            $business_rows
        ]);
        
        //Επιστροφή στη σελίδα διαχείρισης
        header("Location: manage_flights.php");
        exit;
    } catch (PDOException $e) {
        die("Σφάλμα συστήματος κατά την αποθήκευση της πτήσης: " . $e->getMessage());
    }
} else {
    header("Location: manage_flights.php");
    exit;
}
?>