<?php
include_once 'includes/header.php';
require_once 'includes/db.php';

// Ασφάλεια: Μόνο για admins
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'flight_admin' && $_SESSION['role'] !== 'system_admin')) {
    die("Unauthorized access.");
}
?>

<div class="row justify-content-center my-4">
    <div class="col-md-7 col-lg-6">
        <div class="card custom-card p-4 p-md-5 shadow-sm border-0 rounded-4 bg-white">
            
            <div class="border-bottom pb-3 mb-4 text-center">
    <h2 class="text-primary fw-bold h3 mb-1">
        <i class="bi bi-plus-circle-fill me-2"></i><?php echo __('add_new_flight'); ?>
    </h2>
    <p class="text-muted small mb-0"><?php echo __('add_flight_desc'); ?></p>
</div>

            <form action="process_add_flight.php" method="POST">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label small fw-bold text-muted">Αριθμός Πτήσης *</label>
                        <input type="text" class="form-control" name="flight_number" placeholder="π.χ. QA999" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label small fw-bold text-muted">Τύπος Αεροσκάφους *</label>
                        <input type="text" class="form-control" name="airplane" placeholder="π.χ. Airbus A320" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label small fw-bold text-muted">Ημερομηνία Πτήσης *</label>
                        <input type="date" class="form-control" name="flight_date" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label small fw-bold text-muted">Ώρα Πτήσης *</label>
                        <input type="time" class="form-control" name="flight_time" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label small fw-bold text-muted">Σειρές (Rows) *</label>
                        <input type="number" class="form-control" name="rows_count" min="1" max="50" placeholder="π.ex. 10" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label small fw-bold text-muted">Θέσεις ανά Σειρά *</label>
                        <input type="number" class="form-control" name="seats_per_row" min="1" max="6" placeholder="π.ex. 6" required>
                    </div>
                    <div class="col-md-4 mb-4">
                        <label class="form-label small fw-bold text-muted">Business Σειρές *</label>
                        <input type="number" class="form-control" name="business_rows" min="0" max="20" placeholder="π.ex. 2" required>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary w-100 py-2.5 fw-semibold shadow-sm">
                    <i class="bi bi-cloud-arrow-up-fill me-1"></i> Δημιουργία Πτήσης
                </button>
            </form>

            <div class="text-center mt-4 pt-3 border-top">
                <a href="manage_flights.php" class="text-decoration-none text-muted small">
                    <i class="bi bi-arrow-left me-1"></i> Πίσω στη Διαχείριση
                </a>
            </div>
        </div>
    </div>
</div>

<?php include_once 'includes/footer.php'; ?>