<?php
session_start();
require_once 'includes/db.php';

//Ασφάλεια: Μόνο admins
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'flight_admin' && $_SESSION['role'] !== 'system_admin')) {
    die("Unauthorized access.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $flight_number = $_POST['flight_number'];
    $new_status = $_POST['new_status'];
    $current_status = $_POST['current_status'];

    //Προστασία από τροποποίηση τελικών καταστάσεων
    if ($current_status === 'ΑΚΥΡΩΜΕΝΗ' || $current_status === 'ΠΕΡΑΤΩΜΕΝΗ') {
        die("Η πτήση είναι ήδη σε τελική κατάσταση.");
    }

    try {
        $pdo->beginTransaction();

        //Ενημέρωση κατάστασης της πτήσης
        $stmt = $pdo->prepare("UPDATE flights SET status = ? WHERE flight_number = ?");
        $stmt->execute([$new_status, $flight_number]);

        //ΑΛΥΣΙΔΩΤΕΣ ΑΛΛΑΓΕΣ ΣΤΙΣ ΚΡΑΤΗΣΕΙΣ
        if ($new_status === 'ΑΚΥΡΩΜΕΝΗ') {
            //Αν η πτήση ακυρωθεί, ακυρώνονται όλες οι κρατήσεις και αποδεσμεύονται οι θέσεις
            $res_stmt = $pdo->prepare("UPDATE reservations SET status = 'ΑΚΥΡΩΜΕΝΗ', seat_row = NULL, seat_column = NULL WHERE flight_number = ?");
            $res_stmt->execute([$flight_number]);
        } 
        elseif ($new_status === 'ΠΕΡΑΤΩΜΕΝΗ') {
            //Αν η πτήση ολοκληρωθεί, όλες οι ενεργές (μη ακυρωμένες) κρατήσεις γίνονται ΠΕΡΑΤΩΜΕΝΕΣ
            $res_stmt = $pdo->prepare("UPDATE reservations SET status = 'ΠΕΡΑΤΩΜΕΝΗ' WHERE flight_number = ? AND status != 'ΑΚΥΡΩΜΕΝΗ'");
            $res_stmt->execute([$flight_number]);
        }

        $pdo->commit();
        header("Location: manage_flights.php?status_update=success");
        exit();

    } catch (PDOException $e) {
        $pdo->rollBack();
        die("Σφάλμα κατά την ενημέρωση της κατάστασης: " . $e->getMessage());
    }
} else {
    header("Location: manage_flights.php");
    exit();
}
?>