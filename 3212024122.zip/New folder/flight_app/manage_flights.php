<?php
include_once 'includes/header.php';
require_once 'includes/db.php';

if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'flight_admin' && $_SESSION['role'] !== 'system_admin')) {
    die("Unauthorized access.");
}

$stmt = $pdo->query("SELECT * FROM flights ORDER BY flight_date ASC");
$flights = $stmt->fetchAll();
?>

<div class="card custom-card p-4">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h2 class="text-primary fw-bold m-0">
            <i class="bi bi-airplane-fill me-2"></i><?php echo __('manage_flights'); ?>
        </h2>
        <div class="d-flex gap-2">
            <a href="bulk_import_flights.php" class="btn btn-outline-success fw-bold shadow-sm">
                <i class="bi bi-database-add me-1"></i> CSV Import
            </a>
            <a href="add_flight.php" class="btn btn-success fw-bold shadow-sm">
                <i class="bi bi-plus-circle me-1"></i> <?php echo __('add_flight'); ?>
            </a>
        </div>
    </div>

    <?php if (isset($_GET['delete']) && $_GET['delete'] === 'success'): ?>
        <div class="alert alert-success text-center py-2.5 mb-4 small fw-semibold shadow-sm" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo __('flight_deleted_msg'); ?>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['imported']) || isset($_GET['skipped'])): ?>
        <div class="alert alert-success text-center py-2.5 mb-4 small fw-semibold shadow-sm mx-auto" style="max-width: 600px;" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php 
            $ins = isset($_GET['imported']) ? (int)$_GET['imported'] : 0;
            $skp = isset($_GET['skipped']) ? (int)$_GET['skipped'] : 0;
            echo "<strong>" . __('bulk_import') . ":</strong> " . __('inserted_msg') . ": $ins | " . __('ignored_msg') . ": $skp"; 
            ?>
        </div>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="table table-hover align-middle border">
            <thead class="table-light">
                <tr>
                    <th><?php echo __('flight_num'); ?></th>
                    <th><?php echo __('airplane'); ?></th>
                    <th><?php echo __('date_time'); ?></th>
                    <th><?php echo __('total_seats'); ?></th>
                    <th><?php echo __('status'); ?></th>
                    <th><?php echo __('actions'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($flights) === 0): ?>
                    <tr><td colspan="6" class="text-center py-4 text-muted"><?php echo __('no_flights'); ?></td></tr>
                <?php else: ?>
                    <?php foreach ($flights as $flight): ?>
                        <tr>
                            <td class="fw-bold text-primary"><?php echo htmlspecialchars($flight['flight_number']); ?></td>
                            <td><?php echo htmlspecialchars($flight['airplane']); ?></td>
                            <td><?php echo htmlspecialchars($flight['flight_date'] . ' ' . $flight['flight_time']); ?></td>
                            <td><?php echo (int)$flight['total_seats']; ?></td>
                            <td>
                                <span class="badge bg-primary px-2.5 py-1.5"><?php echo __(htmlspecialchars($flight['status'])); ?></span>
                            </td>
                            <td>
                                <div class="d-flex gap-1">
                                    <a href="update_flight_status.php?id=<?php echo urlencode($flight['flight_number']); ?>" class="btn btn-sm btn-primary py-1">
                                        <?php echo __('update'); ?>
                                    </a>
                                    <a href="process_delete_flight.php?id=<?php echo urlencode($flight['flight_number']); ?>" 
                                       class="btn btn-sm btn-danger py-1" 
                                       onclick="return confirm('<?php echo __('confirm_delete_flight_msg'); ?>')">
                                        <i class="bi bi-trash3-fill"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include_once 'includes/footer.php'; ?>