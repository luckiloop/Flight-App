<?php
require_once 'includes/lang.php';
?>
<!DOCTYPE html>
<html lang="<?php echo $current_lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo __('register'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="d-flex flex-column min-vh-100">

<div class="container my-auto py-4">
    <div class="row justify-content-center">
        <div class="col-12 col-sm-10 col-md-7 col-lg-5">
            <div class="card custom-card">
                <div class="text-center mb-4">
                    <span class="fs-1"><i class="bi bi-airplane-fill me-2"></i></span>
                    <h2 class="fw-bold text-primary mt-2"><?php echo __('register'); ?></h2>
                </div>

                <?php if (isset($_GET['error']) && $_GET['error'] === 'user_exists'): ?>
                    <div class="alert alert-danger text-center py-2.5 mb-4 small fw-semibold shadow-sm" role="alert">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i>
                        <?php echo __('user_exists_error'); ?>
                    </div>
                <?php endif; ?>

                <form action="process_register.php" method="POST">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="small fw-bold text-muted"><?php echo __('username'); ?> *</label>
                            <input type="text" class="form-control" name="username" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="small fw-bold text-muted">Email *</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="small fw-bold text-muted"><?php echo __('password'); ?> *</label>
                        <input type="password" class="form-control" name="password" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="small fw-bold text-muted"><?php echo __('first_name_label', 'Όνομα *'); ?></label>
                            <input type="text" class="form-control" name="first_name" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="small fw-bold text-muted"><?php echo __('last_name_label', 'Επώνυμο *'); ?></label>
                            <input type="text" class="form-control" name="last_name" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="small fw-bold text-muted"><?php echo __('id_label', 'Αριθμός Ταυτότητας *'); ?></label>
                        <input type="text" class="form-control" name="identity_number" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="small fw-bold text-muted"><?php echo __('afm_label', 'ΑΦΜ *'); ?></label>
                            <input type="text" class="form-control" name="afm" required>
                        </div>
                        <div class="col-md-6 mb-4">
                            <label class="small fw-bold text-muted"><?php echo __('address_label', 'Διεύθυνση Κατοικίας *'); ?></label>
                            <input type="text" class="form-control" name="address" required>
                        </div>
                    </div>

                    <button class="btn btn-primary w-100 py-2 fw-semibold" type="submit"><?php echo __('submit'); ?></button>
                </form>
                <div class="text-center mt-3"><a href="index.php" class="text-decoration-none text-muted small">← <?php echo __('back_to_menu'); ?></a></div>
            </div>
        </div>
    </div>
</div>

<?php 
include_once 'includes/footer.php'; 
?>
<script src="js/validation.js"></script>
</body>
</html>