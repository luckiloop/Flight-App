<?php
session_start();
require_once 'includes/db.php';

//Ασφάλεια: Μόνο πελάτες
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'customer') {
    die("Unauthorized access.");
}

if (!isset($_GET['res_id'])) {
    header("Location: my_reservations.php");
    exit();
}

$res_id = (int)$_GET['res_id'];
$user_id = $_SESSION['user_id'];

try {
    //Ανάκτηση κράτησης και κατάστασης πτήσης με JOIN
    $sql = "SELECT r.user_id, f.status AS flight_status 
            FROM reservations r
            JOIN flights f ON r.flight_number = f.flight_number
            WHERE r.id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$res_id]);
    $data = $stmt->fetch();

    if (!$data) {
        die("Η κράτηση δεν βρέθηκε.");
    }

    //Έλεγχος ιδιοκτησίας
    if ($data['user_id'] != $user_id) {
        die("Μη εξουσιοδοτημένη ενέργεια.");
    }

    //Έλεγχος αν η πτήση έχει κλείσει (Τελική κατάσταση)
    $final_statuses = ['ΠΕΡΑΤΩΜΕΝΗ', 'ΑΚΥΡΩΜΕΝΗ'];
    if (in_array(strtoupper($data['flight_status']), $final_statuses)) {
        header("Location: my_reservations.php?error=flight_finalized");
        exit();
    }

    //Ακύρωση Κράτησης και Αποδέσμευση Θέσης (NULL)
    $update_sql = "UPDATE reservations 
                   SET status = 'ΑΚΥΡΩΜΕΝΗ', seat_row = NULL, seat_column = NULL 
                   WHERE id = ?";
    $update_stmt = $pdo->prepare($update_sql);
    $update_stmt->execute([$res_id]);

    header("Location: my_reservations.php?cancel=success");
    exit();

} catch (PDOException $e) {
    die("Σφάλμα κατά την ακύρωση: " . $e->getMessage());
}
?>