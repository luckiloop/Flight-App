<?php
include_once 'includes/header.php';
require_once 'includes/db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'customer') { die("Unauthorized access."); }

$stmt = $pdo->query("SELECT flight_number, airplane, flight_date, flight_time, total_seats FROM flights WHERE status = 'ΔΗΜΙΟΥΡΓΗΜΕΝΗ' ORDER BY flight_date ASC");
$flights = $stmt->fetchAll();
?>

<div class="card custom-card p-4 p-md-5" style="min-height: 350px;">
    <h2 class="mb-4 text-primary fw-bold"><i class="bi bi-ticket-perforated me-2"></i><?php echo __('search_flights'); ?></h2>
    <?php if (isset($_GET['booking']) && $_GET['booking'] === 'success'): ?>
    <div class="alert alert-success text-center py-2.5 mb-4 small fw-semibold shadow-sm mx-auto" style="max-width: 600px;" role="alert">
        <i class="bi bi-check-circle-fill me-2"></i>
        <?php echo __('booking_success_msg', 'Η κράτηση θέσης ολοκληρώθηκε με επιτυχία!'); ?>
    </div>
<?php endif; ?>
    
    <div class="table-responsive">
        <table class="table table-hover align-middle border">
            <thead class="table-light">
                <tr>
                    <th><?php echo __('flight_num'); ?></th>
                    <th><?php echo __('airplane'); ?></th>
                    <th><?php echo __('date_time'); ?></th>
                    <th><?php echo __('total_seats'); ?></th>
                    <th><?php echo __('ticket_type'); ?></th>
                    <th><?php echo __('actions'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($flights) == 0): ?>
                    <tr><td colspan="7" class="text-center py-5 text-muted"><?php echo __('no_flights'); ?></td></tr>
                <?php else: ?>
                    <?php foreach ($flights as $flight): ?>
                        <tr>
                            <td class="fw-bold text-primary"><?php echo htmlspecialchars($flight['flight_number']); ?></td>
                            <td><?php echo htmlspecialchars($flight['airplane']); ?></td>
                            <td><?php echo $flight['flight_date'] . ' ' . $flight['flight_time']; ?></td>
                            <td><?php echo $flight['total_seats']; ?></td>
                            <form action="make_reservation.php" method="POST">
                                <input type="hidden" name="flight_number" value="<?php echo htmlspecialchars($flight['flight_number']); ?>">
                                <td>
                                    <select class="form-select form-select-sm" name="ticket_type" style="max-width: 150px;" required>
                                        <option value="ECONOMY">Economy</option>
                                        <option value="NORMAL">Normal</option>
                                        <option value="BUSINESS">Business</option>
                                    </select>
                                </td>
                                <td><button type="submit" class="btn btn-sm btn-success fw-bold"><?php echo __('booking'); ?> </button></td>
                            </form>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include_once 'includes/footer.php'; ?>