<?php
session_start();
require_once 'includes/db.php';

//Ασφάλεια: Μόνο admins μπορούν να διαγράψουν πτήση
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'flight_admin' && $_SESSION['role'] !== 'system_admin')) {
    die("Unauthorized access.");
}

if (!isset($_GET['id'])) {
    header("Location: manage_flights.php");
    exit();
}

$flight_number = $_GET['id'];

try {
    //Ξεκινάμε Transaction για ασφάλεια δεδομένων
    $pdo->beginTransaction();

    //Διαγράφουμε πρώτα όλες τις κρατήσεις που είναι συνδεδεμένες με αυτή την πτήση
    $delete_res_stmt = $pdo->prepare("DELETE FROM reservations WHERE flight_number = ?");
    $delete_res_stmt->execute([$flight_number]);

    //Διαγράφουμε την ίδια την πτήση από τον πίνακα flights
    $delete_flight_stmt = $pdo->prepare("DELETE FROM flights WHERE flight_number = ?");
    $delete_flight_stmt->execute([$flight_number]);

    //Αν όλα πήγαν καλά, αποθηκεύουμε τις αλλαγές οριστικά
    $pdo->commit();

    //Επιστροφή στο μενού με μήνυμα επιτυχίας
    header("Location: manage_flights.php?delete=success");
    exit();

} catch (PDOException $e) {
    // Αν έχει οποιοδήποτε σφάλμα, ακυρώνουμε τα πάντα
    $pdo->rollBack();
    die("Σφάλμα κατά τη διαγραφή της πτήσης: " . $e->getMessage());
}
?>