<?php
session_start();
require_once 'includes/db.php';

//ΕΛΕΓΧΟΣ URL ΓΙΑ XSS & ΠΑΡΑΝΟΜΟΥΣ ΧΑΡΑΚΤΗΡΕΣ (Αποκλεισμός tags <script>, flags, slash κλπ)
if (preg_match('/[<>\'\"\\\;]/', $_SERVER['REQUEST_URI'])) {
    die("Security Exception: Illegal characters detected in URL.");
}

//Ασφάλεια ρόλου
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'customer') {
    die("Unauthorized access.");
}

//ΕΛΕΓΧΟΣ ΥΠΑΡΞΗΣ ΤΙΜΩΝ ΓΙΑ ΥΠΟΧΡΕΩΤΙΚΑ ΠΕΔΙΑ
if (!isset($_GET['res_id']) || trim($_GET['res_id']) === '') {
    die("Error: Missing required parameters.");
}

//ΕΛΕΓΧΟΣ ΕΓΚΥΡΟΤΗΤΑΣ ΤΙΜΩΝ (Πρέπει να είναι αυστηρά ακέραιος αριθμός - XSS Protection)
$res_id = filter_input(INPUT_GET, 'res_id', FILTER_VALIDATE_INT);
if ($res_id === false || $res_id <= 0) {
    die("Error: Invalid parameter format.");
}

$user_id = $_SESSION['user_id'];

try {
    //Ανάκτηση κράτησης για έλεγχο ιδιοκτησίας και τύπου εισιτηρίου
    $sql = "SELECT user_id, type AS ticket_type FROM reservations WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$res_id]);
    $res = $stmt->fetch();

    if (!$res) {
        die("Reservation not found.");
    }

    //Έλεγχος αν η κράτηση ανήκει στον τρέχοντα χρήστη
    if ($res['user_id'] != $user_id) {
        die("Unauthorized operation.");
    }

    //Έλεγχος αν ο τύπος είναι ECONOMY (Απαγορεύεται η αποδέσμευση)
    if (strtoupper($res['ticket_type']) === 'ECONOMY') {
        die("Policy Error: Economy tickets cannot manage seats.");
    }

    //ΕΚΤΕΛΕΣΗ ΑΠΟΔΕΣΜΕΥΣΗΣ: Θέτουμε seat_row και seat_column σε NULL
    $update_sql = "UPDATE reservations SET seat_row = NULL, seat_column = NULL WHERE id = ?";
    $update_stmt = $pdo->prepare($update_sql);
    $update_stmt->execute([$res_id]);

    //Επιστροφή με flag επιτυχίας
    header("Location: my_reservations.php?release=success");
    exit();

} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}
?>