<?php
// Φορτώνει αυτόματα το session, τη γλώσσα, το Bootstrap και το Navbar
include_once 'includes/header.php'; 
?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<?php if (isset($_GET['registration']) && $_GET['registration'] === 'success'): ?>
    <div class="alert alert-success text-center py-3 mb-4 shadow-sm mx-auto" style="max-width: 600px;" role="alert">
        <i class="bi bi-check-circle-fill me-2 fs-5"></i>
        <?php echo __('registration_success_msg'); ?>
    </div>
<?php endif; ?>

<div class="p-4 p-sm-5 bg-white rounded-4 shadow border text-center d-flex flex-column justify-content-center" style="min-height: 400px;">
    <h1 class="display-6 fw-bold text-primary mb-4">Samos Airlines</h1>
    
    <?php if ($role === 'visitor'): ?>
        <p class="fs-5 text-muted"><?php echo __('visitor_msg'); ?></p>
        <div class="mt-3">
            <a href="login.php" class="btn btn-primary btn-lg me-2"><?php echo __('login'); ?></a>
            <a href="register.php" class="btn btn-outline-primary btn-lg"><?php echo __('register'); ?></a>
        </div>
    <?php endif; ?>

    <?php if ($role === 'customer'): ?>
        <div class="customer-panel-box shadow-sm d-flex flex-column align-items-center text-center p-4">
            <h3 class="mb-4 w-100"><i class="bi bi-luggage-fill me-2"></i> <?php echo __('customer_panel'); ?></h3>
            <div class="list-group shadow-sm" style="max-width: 380px;">
                <a href="my_reservations.php" class="list-group-item list-group-item-action fw-semibold py-3"><i class="bi bi-calendar-check me-2"></i> <?php echo __('my_reservations'); ?></a>
                <a href="search_flights.php" class="list-group-item list-group-item-action fw-semibold py-3"><i class="bi bi-search me-2"></i> <?php echo __('search_flights'); ?></a>
                <a href="edit_profile.php" class="list-group-item list-group-item-action fw-semibold py-3"><i class="bi bi-gear-fill me-2"></i> <?php echo __('manage_acc'); ?></a>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($role === 'flight_admin'): ?>
         <div class="admin-panel-box shadow-sm d-flex flex-column align-items-center text-center p-4">
            <h3 class="mb-4 w-100"><i class="bi bi-person me-2"></i> <?php echo __('flight_admin_panel'); ?></h3>
            <div class="list-group shadow-sm" style="max-width: 380px;">
                <a href="manage_flights.php" class="list-group-item list-group-item-action fw-semibold py-3"><i class="bi bi-airplane-fill me-2"></i> <?php echo __('manage_flights'); ?></a>
                <a href="edit_profile.php" class="list-group-item list-group-item-action fw-semibold py-3"><i class="bi bi-gear-fill me-2"></i> <?php echo __('manage_acc'); ?></a>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($role === 'system_admin'): ?>
        <div class="admin-panel-box shadow-sm d-flex flex-column align-items-center text-center p-4">
            <h3 class="mb-3"><i class="bi bi-person-gear me-2"></i> <?php echo __('sys_admin_panel'); ?></h3>
            <div class="list-group shadow-sm" style="max-width: 500px;">
                <a href="manage_users.php" class="list-group-item list-group-item-action fw-semibold py-3"><i class="bi bi-pencil-square me-2"></i> <?php echo __('manage_users'); ?></a>
                <a href="bulk_import.php" class="list-group-item list-group-item-action fw-semibold py-3"><i class="bi bi-database-add me-2"></i> <?php echo __('bulk_import'); ?></a>
                <a href="manage_flights.php" class="list-group-item list-group-item-action fw-semibold py-3"><i class="bi bi-airplane-fill me-2"></i> <?php echo __('manage_flights'); ?></a>
                <a href="edit_profile.php" class="list-group-item list-group-item-action fw-semibold py-3"><i class="bi bi-gear-fill me-2"></i> <?php echo __('manage_acc'); ?></a>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php 
include_once 'includes/footer.php'; 
?>