<?php
include_once 'includes/header.php';
require_once 'includes/db.php';

if (!isset($_SESSION['role'])) { die("Unauthorized."); }
$user_id = $_SESSION['user_id'];

//Αν ο χρήστης πατήσει αποθήκευση
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (!empty($password)) {
        //Αν έβαλε νέο κωδικό, τον κρυπτογραφούμε
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET email = ?, password = ? WHERE id = ?");
        $stmt->execute([$email, $hashed, $user_id]);
    } else {
        //Aν άλλαξε μόνο το email
        $stmt = $pdo->prepare("UPDATE users SET email = ? WHERE id = ?");
        $stmt->execute([$email, $user_id]);
    }
    echo "<div class='alert alert-success text-center mx-auto' style='max-width: 500px;'>" . __('profile_success') . "</div>";
}

//Ανάκτηση τρεχόντων στοιχείων
$stmt = $pdo->prepare("SELECT email FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$u = $stmt->fetch();
?>

<div class="row justify-content-center">
    <div class="col-md-5">
        <div class="card custom-card p-4">
            <h3 class="fw-bold text-primary mb-4"><?php echo __('edit_profile'); ?></h3>
            <form action="edit_profile.php" method="POST">
                <div class="mb-3">
                    <label class="form-label fw-bold"><?php echo __('email_address'); ?></label>
                    <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($u['email']); ?>" required>
                </div>
                <div class="mb-4">
                    <label class="form-label fw-bold"><?php echo __('new_password_msg'); ?></label>
                    <input type="password" class="form-control" name="password" placeholder="••••••••">
                </div>
                <button type="submit" class="btn btn-primary w-100 fw-bold"><?php echo __('update_account'); ?></button>
            </form>
            
            <hr class="my-4 opacity-25">

            <div class="p-3 border border-danger border-opacity-50 rounded-3 bg-danger bg-opacity-10 text-center">
                <h5 class="fw-bold text-danger mb-2 small text-uppercase tracking-wider"><?php echo __('danger_zone'); ?></h5>
                <p class="text-muted small mb-3"><?php echo __('delete_warning_text'); ?></p>
                
                <button type="button" class="btn btn-outline-danger btn-sm fw-semibold" data-bs-toggle="modal" data-bs-target="#deleteAccountModal">
                    <i class="bi bi-trash3-fill me-1"></i> <?php echo __('delete_account_btn'); ?>
                </button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="deleteAccountModal" tabindex="-1" aria-labelledby="deleteAccountModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width: 400px;">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header border-0 pt-4 px-4 d-flex justify-content-center position-relative">
                <h5 class="modal-title fw-bold text-danger text-center w-100" id="deleteAccountModalLabel">
                    <i class="bi bi-exclamation-triangle-fill fs-3 d-block text-danger mb-2"></i>
                    <?php echo __('are_you_sure'); ?>
                </h5>
                <button type="button" class="btn-close position-absolute end-0 top-0 m-3 small" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body px-4 text-center text-muted small">
                <?php echo __('modal_body_text'); ?>
            </div>
            <div class="modal-footer border-0 pb-4 px-4 d-flex gap-2">
                <button type="button" class="btn btn-light w-100 py-2 fw-semibold border" data-bs-dismiss="modal"><?php echo __('cancel'); ?></button>
                <form action="process_delete_account.php" method="POST" class="w-100 m-0">
                    <button type="submit" class="btn btn-danger w-100 py-2 fw-semibold shadow-sm"><?php echo __('yes_delete'); ?></button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once 'includes/footer.php'; ?>