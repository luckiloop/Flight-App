<?php
//εισαγωγή της σύνδεσης με τη βάση
require_once 'includes/db.php';

//Έλεγχος αν η φόρμα υποβλήθηκε μέσω POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    //Συλλογή των κοινών πεδίων
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $identity_number = trim($_POST['identity_number']);
    
    //Ορίζουμε τον ρόλο αυτόματα ως customer
    $role = 'customer'; 
    // $role = 'flight_admin';

    //Συλλογή των ειδικών πεδίων (Χρησιμοποιούμε isset για να μην χτυπάει warning αν λείπουν από τη φόρμα)
    $afm = (isset($_POST['afm'])) ? trim($_POST['afm']) : null;
    $address = (isset($_POST['address'])) ? trim($_POST['address']) : null;
    $employee_code = (isset($_POST['employee_code'])) ? trim($_POST['employee_code']) : null;

    //ΕΛΕΓΧΟΣ ΜΟΝΑΔΙΚΟΤΗΤΑΣ (Username & ΑΤ) 
    $check_stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR identity_number = ?");
    $check_stmt->execute([$username, $identity_number]);
    
    if ($check_stmt->rowCount() > 0) {
        header("Location: register.php?error=user_exists");
        exit();
    }

    //ΚΡΥΠΤΟΓΡΑΦΗΣΗ ΚΩΔΙΚΟΥ
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    //ΕΙΣΑΓΩΓΗ ΣΤΗ ΒΑΣΗ ΔΕΔΟΜΕΝΩΝ 
    $sql = "INSERT INTO users (username, email, password, first_name, last_name, identity_number, role, afm, address, employee_code, status) 
            VALUES (:username, :email, :password, :first_name, :last_name, :identity_number, :role, :afm, :address, :employee_code, 'active')";
    
    $insert_stmt = $pdo->prepare($sql);
    
    try {
        $insert_stmt->execute([
            ':username' => $username,
            ':email' => $email,
            ':password' => $hashed_password,
            ':first_name' => $first_name,
            ':last_name' => $last_name,
            ':identity_number' => $identity_number,
            ':role' => $role,
            ':afm' => $afm,
            ':address' => $address,
            ':employee_code' => $employee_code
        ]);
        
        //Ανακατεύθυνση στο index.php στέλνοντας το flag επιτυχίας
        header("Location: index.php?registration=success");
        exit();
        
    } catch (PDOException $e) {
        die("Σφάλμα συστήματος κατά την εγγραφή: " . $e->getMessage());
    }
} else {
    //Αν κάποιος προσπαθήσει να μπει στο αρχείο χωρίς να υποβάλει φόρμα
    header("Location: register.php");
    exit;
}
?>