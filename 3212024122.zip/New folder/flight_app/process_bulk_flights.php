<?php
session_start();
require_once 'includes/db.php';

if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'flight_admin' && $_SESSION['role'] !== 'system_admin')) {
    die("Unauthorized access.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    $file = $_FILES['csv_file'];

    //Έλεγχος αν είναι όντως CSV
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    if ($ext !== 'csv') {
        die("Σφάλμα: Παρακαλώ ανεβάστε μόνο αρχεία μορφής .csv");
    }

    if (($handle = fopen($file['tmp_name'], "r")) !== FALSE) {
        //Διαβάζουμε την πρώτη γραμμή (headers) για να την προσπεράσουμε
        fgetcsv($handle, 1000, ",");

        $inserted = 0;
        $skipped = 0;

        //Ξεκινάμε Transaction για ταχύτητα και ασφάλεια
        $pdo->beginTransaction();

        $sql = "INSERT INTO flights (flight_number, airplane, flight_date, flight_time, rows_count, seats_per_row, business_rows, total_seats, status) 
                VALUES (:flight_number, :airplane, :flight_date, :flight_time, :rows_count, :seats_per_row, :business_rows, :total_seats, 'ΔΗΜΙΟΥΡΓΗΜΕΝΗ')";
        $stmt = $pdo->prepare($sql);

        //Έλεγχος διπλότυπων
        $check_stmt = $pdo->prepare("SELECT flight_number FROM flights WHERE flight_number = ?");

        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            // Αν η γραμμή είναι άδεια, προσπέρνα την
            if (empty($data) || count($data) < 7) continue;

            $flight_number = trim($data[0]);
            $airplane      = trim($data[1]);
            $flight_date   = trim($data[2]);
            $flight_time   = trim($data[3]);
            $rows_count    = (int)$data[4];
            $seats_per_row = (int)$data[5];
            $business_rows = (int)$data[6];

            //Υπολογισμός συνολικών θέσεων
            $total_seats = $rows_count * $seats_per_row;

            //Έλεγχος αν υπάρχει ήδη ο αριθμός πτήσης
            $check_stmt->execute([$flight_number]);
            if ($check_stmt->rowCount() > 0) {
                $skipped++;
                continue; //Προσπέραση αν υπάρχει ήδη
            }

            $stmt->execute([
                ':flight_number' => $flight_number,
                ':airplane'      => $airplane,
                ':flight_date'   => $flight_date,
                ':flight_time'   => $flight_time,
                ':rows_count'    => $rows_count,
                ':seats_per_row' => $seats_per_row,
                ':business_rows' => $business_rows,
                ':total_seats'   => $total_seats
            ]);
            $inserted++;
        }

        fclose($handle);
        $pdo->commit();

        //Επιστροφή στη διαχείριση με στατιστικά εισαγωγής
        header("Location: manage_flights.php?imported=$inserted&skipped=$skipped");
        exit();
    } else {
        die("Σφάλμα κατά το άνοιγμα του αρχείου.");
    }
} else {
    header("Location: manage_flights.php");
    exit();
}
?>