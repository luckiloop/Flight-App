<?php
session_start();
require_once 'includes/lang.php'; //Κλειδώνει τη γλώσσα του session
require_once 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        if ($user['status'] !== 'active') {
            header("Location: login.php?error=" . urlencode("Disabled account."));
            exit;
        }

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['full_name'] = $user['first_name'] . ' ' . $user['last_name'];

        header("Location: index.php");
        exit;
    } else {
        header("Location: login.php?error=" . urlencode("Wrong credentials."));
        exit;
    }
}
?>