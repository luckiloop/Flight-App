<?php
session_start();
require_once 'includes/db.php';

//Έλεγχος αν ο χρήστης είναι όντως συνδεδεμένος
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];

    try {
        //αν ο χρήστης έχει κρατήσεις, πρέπει να διαγραφούν κι αυτές
        $pdo->beginTransaction();
        $stmt_res = $pdo->prepare("DELETE FROM reservations WHERE user_id = ?");
        $stmt_res->execute([$user_id]);

        //Διαγραφή του ίδιου του χρήστη από τον πίνακα users
        $stmt_user = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt_user->execute([$user_id]);

        //Ολοκλήρωση της διαγραφής στη βάση
        $pdo->commit();

        //Καταστροφή του Session (αποσύνδεση)
        $_SESSION = array();
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httpOnly"]
            );
        }
        session_destroy();

        //Ανακατεύθυνση στην αρχική σελίδα με ένα μήνυμα επιτυχίας
        header("Location: index.php?msg=account_deleted");
        exit();

    } catch (Exception $e) {
        // Σε περίπτωση σφάλματος, ακυρώνουμε τις αλλαγές στη βάση
        $pdo->rollBack();
        die("Σφάλμα κατά τη διαγραφή του λογαριασμού: " . $e->getMessage());
    }
} else {
    // Αν κάποιος προσπαθήσει να μπει στο αρχείο χωρίς POST request, τον πετάμε έξω
    header("Location: index.php");
    exit();
}