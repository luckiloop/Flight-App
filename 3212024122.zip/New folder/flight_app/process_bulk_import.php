<?php
session_start();
require_once 'includes/db.php';

//Ασφάλεια
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'system_admin') {
    die("Μη εξουσιοδοτημένη πρόσβαση.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    $file = $_FILES['csv_file'];

    //Έλεγχος αν υπήρξε σφάλμα στο ανέβασμα
    if ($file['error'] !== UPLOAD_ERR_OK) {
        die("Σφάλμα κατά το ανέβασμα του αρχείου.");
    }

    //Άνοιγμα του αρχείου για ανάγνωση ('r')
    if (($handle = fopen($file['tmp_name'], "r")) !== FALSE) {
        
        $inserted_count = 0;
        $ignored_count = 0;

        //Προετοιμασία των Prepared Statements εκ των προτέρων για μέγιστη ταχύτητα και ασφάλεια
        $check_stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR identity_number = ?");
        
        $insert_sql = "INSERT INTO users (username, email, password, first_name, last_name, identity_number, role, afm, address, employee_code, status) 
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')";
        $insert_stmt = $pdo->prepare($insert_sql);

        //Διάβασμα γραμμή προς γραμμή (χωρίζοντας τα πεδία με κόμμα)
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            
            //Έλεγχος αν η γραμμή έχει τον σωστό αριθμό στηλών (πρέπει να είναι 10 πεδία)
            if (count($data) < 7) {
                $ignored_count++;
                continue; //Λάθος δομή, προσπέραση γραμμής
            }

            //Αντιστοίχηση στηλών σε μεταβλητές
            $username        = trim($data[0]);
            $email           = trim($data[1]);
            $plain_password  = trim($data[2]);
            $first_name      = trim($data[3]);
            $last_name       = trim($data[4]);
            $identity_number = trim($data[5]);
            $role            = trim($data[6]); // customer, flight_admin, system_admin
            
            // Προαιρετικά πεδία
            $afm           = isset($data[7]) && $data[7] !== '' ? trim($data[7]) : null;
            $address       = isset($data[8]) && $data[8] !== '' ? trim($data[8]) : null;
            $employee_code = isset($data[9]) && $data[9] !== '' ? trim($data[9]) : null;

            //Έλεγχος Username και ΑΤ
            $check_stmt->execute([$username, $identity_number]);
            if ($check_stmt->rowCount() > 0) {
                $ignored_count++;
                continue; //Ο χρήστης υπάρχει ήδη, αγνοείται η γραμμή (Απαίτηση εκφώνησης)
            }

            //Κρυπτογράφηση του password
            $hashed_password = password_hash($plain_password, PASSWORD_DEFAULT);

            //Εισαγωγή στη βάση δεδομένων
            try {
                $insert_stmt->execute([
                    $username, $email, $hashed_password, $first_name, $last_name,
                    $identity_number, $role, $afm, $address, $employee_code
                ]);
                $inserted_count++;
            } catch (PDOException $e) {
                $ignored_count++; // Αν εμφανιστεί κάποιο άλλο error
            }
        }
        
        fclose($handle);

        //Εμφάνιση αποτελεσμάτων στον Admin
        echo "<main class='main-content' style='font-family: sans-serif; padding: 20px;'>";
        echo "<h2>Αποτέλεσμα Μαζικής Εισαγωγής</h2>";
        echo "<p style='color: green; font-weight: bold;'>Εισήχθησαν επιτυχώς: $inserted_count χρήστες.</p>";
        echo "<p style='color: orange; font-weight: bold;'>Αγνοήθηκαν (λόγω διπλοεγγραφών ή λαθών): $ignored_count γραμμές.</p>";
        echo "<br><a href='index.php' class='btn' style='text-decoration: none; background: #95b7ff; color: white; padding: 10px 15px; border-radius: 4px;'>Επιστροφή στο Dashboard</a>";
        echo "</main>";

    } else {
        die("Αδυναμία ανάγνωσης του αρχείου.");
    }
} else {
    header("Location: bulk_import.php");
    exit;
}
?>