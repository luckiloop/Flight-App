<?php
include_once 'includes/header.php';
require_once 'includes/db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'customer') { 
    die("Unauthorized access."); 
}
$user_id = $_SESSION['user_id'];

$sql = "SELECT r.id AS res_id, r.flight_number, r.type AS ticket_type, r.seat_row, r.seat_column, r.status AS res_status,
               f.rows_count, f.seats_per_row, f.business_rows, f.flight_date, f.flight_time
        FROM reservations r
        JOIN flights f ON r.flight_number = f.flight_number
        WHERE r.user_id = ? AND r.status != 'ΑΚΥΡΩΜΕΝΗ'
        ORDER BY f.flight_date ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute([$user_id]);
$reservations = $stmt->fetchAll();
?>

<div class="container my-5">
    <div class="card custom-card p-4 p-md-5 mx-auto shadow-sm border-0 rounded-4 bg-white" style="max-width: 900px;">
        
        <div class="text-center w-100 mb-4 border-bottom pb-3">
            <h2 class="text-primary fw-bold display-6 mb-1">
                <i class="bi bi-calendar-check me-2"></i><?php echo __('my_reservations'); ?>
            </h2>
        </div>
        <?php if (isset($_GET['release']) && $_GET['release'] === 'success'): ?>
    <div class="alert alert-success text-center py-2.5 mb-4 small fw-semibold shadow-sm" role="alert">
        <i class="bi bi-check-circle-fill me-2"></i>
        <?php echo __('seat_released_msg', 'Η θέση σας αποδεσμεύτηκε με επιτυχία και είναι πλέον διαθέσιμη.'); ?>
    </div>
<?php endif; ?>

        <?php if (isset($_GET['cancel']) && $_GET['cancel'] === 'success'): ?>
            <div class="alert alert-success text-center py-2.5 mb-4 small fw-semibold shadow-sm" role="alert">
                <i class="bi bi-check-circle-fill me-2"></i>
                <?php echo __('cancel_success_msg', 'Η κράτησή σας ακυρώθηκε και η θέση σας αποδεσμεύτηκε με επιτυχία.'); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_GET['error']) && $_GET['error'] === 'flight_finalized'): ?>
            <div class="alert alert-danger text-center py-2.5 mb-4 small fw-semibold shadow-sm" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                <?php echo __('cancel_error_finalized', 'Δεν είναι δυνατή η ακύρωση της κράτησης, καθώς η πτήση έχει ήδη πραγματοποιηθεί ή ακυρωθεί.'); ?>
            </div>
        <?php endif; ?>

        <div class="card-body p-0 w-100">
            <?php if (count($reservations) == 0): ?>
                <div class="alert alert-info text-center shadow-sm mb-0"><?php echo __('no_flights'); ?></div>
            <?php else: ?>
                
                <?php foreach ($reservations as $res): ?>
                    <div class="p-4 mb-4 border rounded-4 bg-light bg-opacity-50 shadow-sm">
                        
                        <div class="d-flex justify-content-between align-items-center border-bottom pb-3 mb-3 flex-wrap gap-2">
                            <h4 class="text-primary fw-bold h5 m-0">
                                <i class="bi bi-airplane-engines me-2"></i><?php echo __('flight_num'); ?>: <?php echo htmlspecialchars($res['flight_number']); ?>
                            </h4>
                            <div class="d-flex align-items-center gap-2">
                                <span class="badge bg-secondary py-2 px-3 text-uppercase"><?php echo htmlspecialchars($res['ticket_type']); ?></span>
                                
                                <a href="process_cancel_reservation.php?res_id=<?php echo $res['res_id']; ?>" 
                                   class="btn btn-sm btn-outline-danger fw-semibold" 
                                   onclick="return confirm('<?php echo __('confirm_cancel_msg', 'Είστε βέβαιοι ότι θέλετε να ακυρώσετε αυτή την κράτηση;'); ?>')">
                                    <i class="bi bi-x-circle me-1"></i> <?php echo __('cancel_booking_btn', 'Ακύρωση'); ?>
                                </a>
                            </div>
                        </div>

                        <p class="text-muted small mb-2"><i class="bi bi-calendar-day me-2"></i> <?php echo $res['flight_date'] . ' ' . $res['flight_time']; ?></p>
                        <p class="mb-4 fs-5 d-flex align-items-center gap-2 flex-wrap">
    <?php echo __('current_seat'); ?>: 
    <strong class="text-dark bg-white px-2 py-1 rounded border small">
        <?php echo ($res['seat_row'] !== null) ? __('row') . " " . $res['seat_row'] . ", " . chr(64 + $res['seat_column']) : __('no_seat_selected'); ?>
    </strong>
    
    <?php if ($res['seat_row'] !== null && strtoupper($res['ticket_type']) !== 'ECONOMY'): ?>
        <a href="process_release_seat.php?res_id=<?php echo $res['res_id']; ?>" 
           class="btn btn-sm btn-link text-danger text-decoration-none p-0 ms-2 fw-semibold"
           onclick="return confirm('<?php echo __('confirm_release_seat', 'Θέλετε να απελευθερώσετε τη θέση σας;'); ?>')">
            <i class="bi bi-unlock-fill me-1"></i><?php echo __('release_seat_btn', 'Αποδέσμευση Θέσης'); ?>
        </a>
    <?php endif; ?>
</p>

                        <?php if (strtoupper($res['ticket_type']) === 'ECONOMY'): ?>
                            <div class="alert alert-warning py-2.5 mb-0 small border-0 opacity-75">
                                <i class="bi bi-exclamation-triangle-fill me-1"></i> <?php echo __('economy_notice'); ?>
                            </div>
                        <?php else: ?>
                            <h6 class="fw-bold text-secondary mt-3 mb-2"><i class="bi bi-grid-3x3-gap me-2"></i><?php echo __('seat_map'); ?>:</h6>
                            <div class="airplane-grid text-center d-flex flex-column align-items-center mt-2 bg-white p-3 rounded-3 border">
                                <?php
                                $seat_stmt = $pdo->prepare("SELECT seat_row, seat_column, user_id FROM reservations WHERE flight_number = ? AND seat_row IS NOT NULL AND status != 'ΑΚΥΡΩΜΕΝΗ'");
                                $seat_stmt->execute([$res['flight_number']]);
                                $occupied_seats = [];
                                while ($row = $seat_stmt->fetch()) { $occupied_seats[$row['seat_row']][$row['seat_column']] = $row['user_id']; }

                                for ($i = 1; $i <= $res['rows_count']; $i++) {
                                    $is_business_row = ($i <= $res['business_rows']);
                                    echo '<div class="row-container">';
                                    echo '<span class="row-label">' . ($is_business_row ? '<i class="bi bi-star-fill text-warning me-1"></i>' : '') . __('row') . ' ' . $i . '</span>';
                                    for ($j = 1; $j <= $res['seats_per_row']; $j++) {
                                        $seat_class = "seat"; $disabled = false;
                                        if ($is_business_row) { $seat_class .= " business"; }
                                        if (isset($occupied_seats[$i][$j])) {
                                            if ($occupied_seats[$i][$j] == $user_id) { $seat_class .= " selected"; } 
                                            else { $seat_class .= " occupied"; $disabled = true; }
                                        }
                                        if (strtoupper($res['ticket_type']) === 'NORMAL' && $is_business_row) { $seat_class .= " disabled"; $disabled = true; }

                                        if (!$disabled) { echo "<a href='select_seat.php?res_id={$res['res_id']}&row={$i}&col={$j}' class='{$seat_class}'>" . chr(64 + $j) . "</a>"; } 
                                        else { echo "<span class='{$seat_class}'>" . chr(64 + $j) . "</span>"; }
                                    }
                                    echo '</div>';
                                }
                                ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
                
            <?php endif; ?>
        </div> </div> </div> <?php include_once 'includes/footer.php'; ?>