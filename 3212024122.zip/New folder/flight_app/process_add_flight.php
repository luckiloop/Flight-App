<?php
session_start();
require_once 'includes/db.php';

if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'flight_admin' && $_SESSION['role'] !== 'system_admin')) {
    die("Unauthorized access.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $flight_number = trim($_POST['flight_number']);
    $airplane = trim($_POST['airplane']);
    $flight_date = $_POST['flight_date'];
    $flight_time = $_POST['flight_time'];
    $rows_count = (int)$_POST['rows_count'];
    $seats_per_row = (int)$_POST['seats_per_row'];
    $business_rows = (int)$_POST['business_rows'];
    
    //Υπολογισμός συνολικών θέσεων
    $total_seats = $rows_count * $seats_per_row;

    //Έλεγχος αν ο αριθμός πτήσης υπάρχει ήδη
    $check = $pdo->prepare("SELECT flight_number FROM flights WHERE flight_number = ?");
    $check->execute([$flight_number]);
    if ($check->rowCount() > 0) {
        die("Σφάλμα: Αυτός ο αριθμός πτήσης υπάρχει ήδη!");
    }

    $sql = "INSERT INTO flights (flight_number, airplane, flight_date, flight_time, rows_count, seats_per_row, business_rows, total_seats, status) 
            VALUES (:flight_number, :airplane, :flight_date, :flight_time, :rows_count, :seats_per_row, :business_rows, :total_seats, 'ΔΗΜΙΟΥΡΓΗΜΕΝΗ')";
    
    $stmt = $pdo->prepare($sql);

    try {
        $stmt->execute([
            ':flight_number' => $flight_number,
            ':airplane' => $airplane,
            ':flight_date' => $flight_date,
            ':flight_time' => $flight_time,
            ':rows_count' => $rows_count,
            ':seats_per_row' => $seats_per_row,
            ':business_rows' => $business_rows,
            ':total_seats' => $total_seats
        ]);

        header("Location: manage_flights.php");
        exit();
    } catch (PDOException $e) {
        die("Σφάλμα κατά την προσθήκη πτήσης: " . $e->getMessage());
    }
} else {
    header("Location: manage_flights.php");
    exit();
}
?>