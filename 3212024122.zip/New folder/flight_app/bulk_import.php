<?php
include_once 'includes/header.php';
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'system_admin') { die("Unauthorized access."); }
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card custom-card p-4">
            <h3 class="mb-4 text-primary fw-bold"><i class="bi bi-database-add me-2"></i> <?php echo __('bulk_import'); ?></h3>
            <form action="process_bulk_import.php" method="POST" enctype="multipart/form-data">
                <div class="mb-4">
                    <label class="form-label text-muted small">Select a valid .csv template</label>
                    <input class="form-control" type="file" name="csv_file" accept=".csv" required>
                </div>
                <button type="submit" class="btn btn-primary w-100 py-2 fw-bold"><?php echo __('submit'); ?> <i class="bi bi-send me-2"></i></button>
            </form>
        </div>
    </div>
</div>

<?php include_once 'includes/footer.php'; ?>