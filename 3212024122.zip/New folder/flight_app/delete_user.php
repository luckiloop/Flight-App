<?php
session_start();
require_once 'includes/db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'system_admin') {
    die("Μη εξουσιοδοτημένη πρόσβαση.");
}

if (isset($_GET['id'])) {
    $user_id = (int)$_GET['id'];

    // Διαγραφή του χρήστη (σβήνονται αυτόματα και οι κρατήσεις του)
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
}

header("Location: manage_users.php");
exit;
?>