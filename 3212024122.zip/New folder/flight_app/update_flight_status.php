<?php
//Φορτώνει αυτόματα το session, τη γλώσσα, το Bootstrap και το Navbar
include_once 'includes/header.php'; 
require_once 'includes/db.php';

//Ασφάλεια: Μόνο admins
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'flight_admin' && $_SESSION['role'] !== 'system_admin')) {
    die("Μη εξουσιοδοτημένη πρόσβαση.");
}

if (!isset($_GET['id'])) {
    header("Location: manage_flights.php");
    exit;
}

$flight_number = $_GET['id'];

//Ανάκτηση της τρέχουσας κατάστασης της πτήσης
$stmt = $pdo->prepare("SELECT * FROM flights WHERE flight_number = ?");
$stmt->execute([$flight_number]);
$flight = $stmt->fetch();

if (!$flight) {
    die("Η πτήση δεν βρέθηκε.");
}

$current_status = $flight['status'];
?>

<div class="container d-flex flex-column align-items-center justify-content-center my-5" style="min-height: 75vh;">
    
    <div class="card custom-card p-4 p-md-5 w-100 shadow-sm border-0 rounded-4 bg-white text-center" style="max-width: 600px;">
        
        <div class="border-bottom pb-3 mb-4">
            <h2 class="text-primary fw-bold h3 mb-2">
                <i class="bi bi-arrow-repeat me-2"></i><?php echo __('change_flight_status', 'Αλλαγή Κατάστασης Πτήσης'); ?>
            </h2>
            <span class="badge bg-dark px-3 py-2 fs-6"># <?php echo htmlspecialchars($flight_number); ?></span>
        </div>

        <div class="card-body p-0">
            <h4 class="fw-semibold mb-4 text-secondary">
                <?php echo __('current_status', 'Τρέχουσα Κατάσταση'); ?>: 
                <span class="badge bg-primary px-3 py-2 ms-2">
                    <?php 
                    $status_key = strtoupper($current_status);
                    // Αν η βάση επιστρέφει "CREATED", το μεταφράζουμε βάσει του κλειδιού 'ΔΗΜΙΟΥΡΓΗΜΕΝΗ'
                    if ($status_key === 'CREATED') $status_key = 'ΔΗΜΙΟΥΡΓΗΜΕΝΗ';
                    echo __($status_key); 
                    ?>
                </span>
            </h4>
            
            <?php if (strtoupper($current_status) === 'ΑΚΥΡΩΜΕΝΗ' || strtoupper($current_status) === 'ΠΕΡΑΤΩΜΕΝΗ' || $current_status === 'Completed' || $current_status === 'Cancelled'): ?>
                <div class="alert alert-danger d-flex align-items-center justify-content-center py-3 shadow-sm mb-4" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2 fs-5"></i>
                    <div class="fw-medium small">
                        <?php echo __('flight_final_status_msg', 'Η πτήση βρίσκεται σε τελική κατάσταση και δεν μπορεί να τροποποιηθεί.'); ?>
                    </div>
                </div>
            <?php else: ?>
                <form action="process_status_change.php" method="POST" class="text-start mx-auto" style="max-width: 400px;">
                    <input type="hidden" name="flight_number" value="<?php echo htmlspecialchars($flight_number); ?>">
                    <input type="hidden" name="current_status" value="<?php echo htmlspecialchars($current_status); ?>">
                    
                    <div class="mb-4">
                        <label for="new_status" class="form-label fw-semibold text-muted mb-2"><?php echo __('select_new_status_label', 'Επιλέξτε Νέα Κατάσταση: *'); ?></label>
                        <select name="new_status" id="new_status" class="form-select form-select-lg py-2 fs-6" required>
                            <?php if (strtoupper($current_status) === 'ΔΗΜΙΟΥΡΓΗΜΕΝΗ' || strtoupper($current_status) === 'CREATED'): ?>
                                <option value="ΣΤΕΛΕΧΩΜΕΝΗ"><?php echo __('ΣΤΕΛΕΧΩΜΕΝΗ', 'ΣΤΕΛΕΧΩΜΕΝΗ'); ?></option>
                                <option value="ΑΚΥΡΩΜΕΝΗ"><?php echo __('ΑΚΥΡΩΜΕΝΗ', 'ΑΚΥΡΩΜΕΝΗ'); ?></option>
                            <?php elseif (strtoupper($current_status) === 'ΣΤΕΛΕΧΩΜΕΝΗ'): ?>
                                <option value="ΠΕΡΑΤΩΜΕΝΗ"><?php echo __('ΠΕΡΑΤΩΜΕΝΗ', 'ΠΕΡΑΤΩΜΕΝΗ'); ?></option>
                                <option value="ΑΚΥΡΩΜΕΝΗ"><?php echo __('ΑΚΥΡΩΜΕΝΗ', 'ΑΚΥΡΩΜΕΝΗ'); ?></option>
                            <?php endif; ?>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100 py-2.5 fw-semibold shadow-sm">
                        <?php echo __('update_status_btn', 'Ενημέρωση Κατάστασης'); ?>
                    </button>
                </form>
            <?php endif; ?>
            
            <div class="mt-4 pt-3 border-top">
                <a href="manage_flights.php" class="text-decoration-none text-muted small">
                    <i class="bi bi-arrow-left me-1"></i><?php echo __('back_to_flights', 'Επιστροφή στις Πτήσεις'); ?>
                </a>
            </div>

        </div> 
    </div> 
</div>
include_once 'includes/footer.php'; 
?>