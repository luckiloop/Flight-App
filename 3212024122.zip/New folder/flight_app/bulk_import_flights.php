<?php
include_once 'includes/header.php';
require_once 'includes/db.php';

// Ασφάλεια: Μόνο για admins
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'flight_admin' && $_SESSION['role'] !== 'system_admin')) {
    die("Unauthorized access.");
}
?>

<div class="row justify-content-center my-4">
    <div class="col-md-7 col-lg-6">
        <div class="card custom-card p-4 p-md-5 shadow-sm border-0 rounded-4 bg-white">
            
            <div class="border-bottom pb-3 mb-4 text-center">
                <h2 class="text-primary fw-bold h3 mb-1">
                    <i class="bi bi-database-add me-2"></i><?php echo __('bulk_import_flights', 'Μαζική Εισαγωγή Πτήσεων'); ?>
                </h2>
                <p class="text-muted small mb-0">Ανεβάστε ένα αρχείο CSV για αυτόματη εισαγωγή πολλαπλών πτήσεων</p>
            </div>

            <form action="process_bulk_flights.php" method="POST" enctype="multipart/form-data">
                <div class="mb-4">
                    <label for="csv_file" class="form-label small fw-bold text-muted">Επιλέξτε αρχείο CSV (.csv) *</label>
                    <input class="form-control" type="file" id="csv_file" name="csv_file" accept=".csv" required>
                </div>

                <button type="submit" class="btn btn-success w-100 py-2.5 fw-semibold shadow-sm">
                    <i class="bi bi-upload me-1"></i> Εκτέλεση Εισαγωγής
                </button>
            </form>

            <div class="mt-4 p-3 bg-light rounded-3 border">
                <h6 class="fw-bold text-secondary mb-2 small"><i class="bi bi-info-circle-fill me-1"></i> Δομή Αρχείου CSV:</h6>
                <p class="text-muted mb-2" style="font-size: 0.8rem;">Το CSV πρέπει να έχει ως πρώτη γραμμή (header) τα παρακάτω πεδία χωρισμένα με κόμμα ( , ):</p>
            </div>

            <div class="text-center mt-4 pt-3 border-top">
                <a href="manage_flights.php" class="text-decoration-none text-muted small">
                    <i class="bi bi-arrow-left me-1"></i> Πίσω στη Διαχείριση
                </a>
            </div>
        </div>
    </div>
</div>

<?php include_once 'includes/footer.php'; ?>