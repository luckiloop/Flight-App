<?php
require_once 'includes/lang.php';
?>
<!DOCTYPE html>
<html lang="<?php echo $current_lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo __('login'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="d-flex flex-column min-vh-100">

<div class="container d-flex justify-content-end pt-3">
    <div class="btn-group btn-group-sm" role="group">
        <a href="?lang=el" class="btn btn-outline-primary lang-btn <?php echo $current_lang === 'el' ? 'active' : ''; ?>">GR</a>
        <a href="?lang=en" class="btn btn-outline-primary lang-btn <?php echo $current_lang === 'en' ? 'active' : ''; ?>">EN</a>
    </div>
</div>

<div class="container my-auto">
    <div class="row justify-content-center">
        <div class="col-12 col-sm-8 col-md-5 col-lg-4">
            <div class="card custom-card">
                <div class="text-center mb-4">
                    <span class="fs-1"> <i class="bi bi-airplane-fill me-2"></i> </span>
                    <h2 class="fw-bold text-primary mt-2"><?php echo __('login'); ?></h2>
                </div>
                
                <?php if (isset($_GET['error'])): ?>
                    <div class="alert alert-danger py-2 text-center small"><?php echo htmlspecialchars($_GET['error']); ?></div>
                <?php endif; ?>

                <form action="process_login.php" method="POST">
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" id="username" name="username" placeholder="Username" required>
                        <label for="username"><?php echo __('username'); ?></label>
                    </div>

                    <div class="form-floating mb-4">
                        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                        <label for="password"><?php echo __('password'); ?></label>
                    </div>

                    <button class="btn btn-primary w-100 py-2 fw-semibold" type="submit"><?php echo __('submit'); ?></button>
                </form>
                <div class="text-center mt-3"><a href="index.php" class="text-decoration-none text-muted small">← <?php echo __('cancel'); ?></a></div>
            </div>
        </div>
    </div>
</div>

</body>
</html>