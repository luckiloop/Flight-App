document.addEventListener("DOMContentLoaded", function() {
    const roleSelect = document.getElementById("role");
    const customerFields = document.getElementById("customer-fields");
    const employeeFields = document.getElementById("employee-fields");
    
    const afmInput = document.getElementById("afm");
    const addressInput = document.getElementById("address");
    const empCodeInput = document.getElementById("employee_code");

        afmInput.required = true;
    addressInput.required = true;

    roleSelect.addEventListener("change", function() {
        if (roleSelect.value === "customer") {
            // Εμφάνιση πεδίων πελάτη - Απόκρυψη υπαλλήλου
            customerFields.style.display = "block";
            employeeFields.style.display = "none";
            
            // Ρύθμιση Required
            afmInput.required = true;
            addressInput.required = true;
            empCodeInput.required = false;
            empCodeInput.value = ""; // Καθαρισμός αν είχε γραφτεί κάτι
        } else if (roleSelect.value === "flight_admin") {
            // Εμφάνιση πεδίων υπαλλήλου - Απόκρυψη πελάτη
            customerFields.style.display = "none";
            employeeFields.style.display = "block";
            
            // Ρύθμιση Required
            afmInput.required = false;
            addressInput.required = false;
            empCodeInput.required = true;
            afmInput.value = "";
            addressInput.value = "";
        }
    });
});