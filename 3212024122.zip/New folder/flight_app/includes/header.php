<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/lang.php';

$role = isset($_SESSION['role']) ? $_SESSION['role'] : 'visitor';
$full_name = isset($_SESSION['full_name']) ? $_SESSION['full_name'] : '';
?>
<!DOCTYPE html>
<html lang="<?php echo $current_lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Samos Airlines App</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark navbar-custom shadow-sm mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold d-flex align-items-center" href="index.php">
    <i class="bi bi-airplane-engines-fill me-2"></i> Samos AirLines app
</a>
        
        <div class="d-flex align-items-center ms-auto">
            <div class="btn-group btn-group-sm me-3" role="group">
                <a href="?lang=el" class="btn btn-outline-light lang-btn <?php echo ($current_lang === 'el') ? 'active' : ''; ?>">GR</a>
                <a href="?lang=en" class="btn btn-outline-light lang-btn <?php echo ($current_lang === 'en') ? 'active' : ''; ?>">EN</a>
            </div>

            <div class="text-white">
                <?php if ($role === 'visitor'): ?>
                    <a href="login.php" class="btn btn-light btn-sm fw-bold"><?php echo __('login'); ?></a>
                <?php else: ?>
                    <span class="me-3 opacity-75"><?php echo __('welcome'); ?>, <strong><?php echo htmlspecialchars($full_name); ?></strong></span>
                    <a href="logout.php" class="btn btn-danger btn-sm"><?php echo __('logout'); ?></a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<div class="container">