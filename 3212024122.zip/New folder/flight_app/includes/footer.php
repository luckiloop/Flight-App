<footer class="w-100 py-3 mt-auto" style="background: transparent;">
        <div class="container text-center">
            <p class="mb-1 small fw-medium text-white-50">
                &copy; <?php echo date('Y'); ?> Samos Airlines. All Rights Reserved.
            </p>
          
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>