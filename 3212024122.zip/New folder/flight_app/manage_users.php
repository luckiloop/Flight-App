<?php
include_once 'includes/header.php';
require_once 'includes/db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'system_admin') { die("Unauthorized access."); }

$search = "";
$query = "SELECT * FROM users WHERE id != ?";
$params = [$_SESSION['user_id']];

if (isset($_GET['search']) && trim($_GET['search']) !== '') {
    $search = trim($_GET['search']);
    $query .= " AND (username LIKE ? OR last_name LIKE ? OR identity_number LIKE ? OR afm LIKE ?)";
    $search_param = "%$search%";
    $params = array_merge($params, [$search_param, $search_param, $search_param, $search_param]);
}

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$users = $stmt->fetchAll();
?>

<div class="card custom-card p-4 mb-4">
    <form action="manage_users.php" method="GET" class="row g-2 align-items-center">
        <div class="col-auto">
            <label class="fw-bold mb-0"><?php echo __('search_user'); ?>:</label>
        </div>
        <div class="col-sm-6 col-md-4">
            <input type="text" class="form-control form-control-sm" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Username, Last name...">
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-sm btn-primary px-3"><i class="bi bi-search me-2"></i></button>
        </div>
    </form>
</div>

<div class="card custom-card p-4">
    <div class="table-responsive">
        <table class="table table-hover align-middle border">
            <thead class="table-light">
                <tr>
                    <th><?php echo __('username'); ?></th>
                    <th><?php echo __('fullname'); ?></th>
                    <th><?php echo __('role'); ?></th>
                    <th><?php echo __('id_info'); ?></th>
                    <th><?php echo __('status'); ?></th>
                    <th><?php echo __('actions'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $u): ?>
                    <tr>
                        <td class="fw-bold"><?php echo htmlspecialchars($u['username']); ?></td>
                        
                        <td><?php echo htmlspecialchars($u['first_name'] . ' ' . $u['last_name']); ?></td>
                        
                        <td><span class="badge bg-light text-dark border"><?php echo __(htmlspecialchars($u['role'])); ?></span></td>
                        
                        <td class="small">ID: <?php echo htmlspecialchars($u['identity_number']); ?></td>
                        
                        <td>
                            <span class="badge <?php echo ($u['status'] === 'active') ? 'bg-success' : 'bg-danger'; ?>">
                                <?php echo __($u['status']); ?>
                            </span>
                        </td>
                        
                        <td>
                            <a href="toggle_user_status.php?id=<?php echo $u['id']; ?>" class="btn btn-sm btn-dark py-1 px-2 small">
                                <?php echo ($u['status'] === 'active') ? __('deactivate') : __('activate'); ?>
                            </a>
                            <a href="delete_user.php?id=<?php echo $u['id']; ?>" onclick="return confirm('Confirm?');" class="btn btn-sm btn-outline-danger py-1 px-2 small ms-2">
                                <?php echo __('delete'); ?>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include_once 'includes/footer.php'; ?>